# THIS FILE IS GENERATED FROM DNACC SETUP.PY
short_version = '1.0.0'
version = '1.0.0'
full_version = '1.0.0.dev-071df96'
git_revision = '071df96b98663a9de86382f4fd193a930373a156'
release = False

if not release:
    version = full_version
