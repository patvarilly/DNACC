.. DNACC documentation master file, created by
   sphinx-quickstart on Sun Feb 19 00:13:40 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

DNACC
=====

DNACC is a Python module for calculating DNACC interaction potentials and
binding details

:Version: |version|
:Date: |today|

Contents:

.. toctree::
   :maxdepth: 1

   quickstart
   reference
   

Indices and tables:

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

