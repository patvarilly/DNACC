RT is the sphere-sphere potential of the AB-AB system, derived from an MC
treatment of AB-AB plates (../tethers_AB_AB.txt), followed by a Derjaguin
approximation.
