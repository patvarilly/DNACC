RT is the sphere-sphere potential of the A-B system, derived from an MC
treatment of A-B plates (../tethers_A_B.dat), followed by a Derjaguin
approximation.
