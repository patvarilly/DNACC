V_T.N is the sphere-sphere potential for A-B spheres at temperature T (in
Celsius).  N is the index of the realisation of the tethers on the spheres.
The columns are (1) h in nm, (2) V in kT.

Similary, the potential decomposes into an attractive part Vatt and Vrep.
