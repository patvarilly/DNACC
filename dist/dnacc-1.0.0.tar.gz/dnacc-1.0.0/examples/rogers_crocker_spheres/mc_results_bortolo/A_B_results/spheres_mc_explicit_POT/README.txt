V_T is the sphere-sphere pair potential for the A-B system, averaged over 14
realisations of the tether grafting points on the spheres.  It is generated
by the script media.sh.  The columns are (1) h in nm, and (2) V in kT.  It
decomposes into an attractive portion, V_att, and a repulsive portion,
V_rep.




