dxx sticky end distance as obtained by Rosenbluth
dcbgxx                  as obtained by Conf Bias GC
