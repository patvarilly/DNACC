This folder contains the results of a Monte Carlo simulation (a la Leunissen
and Frenkel, JCP 2011) calculating the number of alpha - alpha' bonds formed
between parallel plates, and the resulting plate-plate potential

The file potential.DG is the plate-plate potential, in units of kT / (20 nm)**2, as a function of (plate separation) / (20 nm)
